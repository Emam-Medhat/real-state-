@extends('layouts.app')

@section('title', 'تواصل معنا')

@section('content')

@if($maintenanceRequest)
    <div>
        <p>نوع المشكلة: {{ $maintenanceRequest->issue_type }}</p>
        <p>الوصف: {{ $maintenanceRequest->description }}</p>
        <p>الأولوية: {{ $maintenanceRequest->priority }}</p>
        <p>الحالة: {{ $maintenanceRequest->status }}</p>
    </div>
@else
    <p>لا توجد بيانات لعرضها.</p>
@endif


@endsection