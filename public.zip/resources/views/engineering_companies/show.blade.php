@extends('layouts.app')

@section('title', 'تواصل معنا')

@section('content')
<style>
    :root {
        --primary-color: #2C3E50;
        --secondary-color: #3498DB;
        --accent-color: #E74C3C;
        --light-color: #F8F9FA;
        --dark-color: #1A252F;
        --text-color: #333333;
        --text-light: #7F8C8D;
        --border-radius-lg: 16px;
        --border-radius-sm: 8px;
        --box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
    }

    body {
        font-family: 'Cairo', sans-serif;
        background-color: #f8fafc;
        color: var(--text-color);
        line-height: 1.7;
    }

    .company-container {
        max-width: 1400px;
        margin: 3rem auto;
        background: white;
        border-radius: var(--border-radius-lg);
        box-shadow: var(--box-shadow);
        overflow: hidden;
        animation: fadeIn 0.8s ease-out;
    }

    .company-header {
        background: linear-gradient(135deg, var(--primary-color), var(--dark-color));
        color: white;
        padding: 4rem 2rem;
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .company-header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fill-opacity='0.05' fill-rule='evenodd'/%3E%3C/svg%3E");
    }

    .company-title {
        font-size: 2.8rem;
        font-weight: 800;
        margin-bottom: 0.8rem;
        position: relative;
        display: inline-block;
    }

    .company-title::after {
        content: '';
        position: absolute;
        bottom: -12px;
        left: 50%;
        transform: translateX(-50%);
        width: 100px;
        height: 5px;
        background: var(--accent-color);
        border-radius: 3px;
    }

    .company-subtitle {
        font-size: 1.3rem;
        opacity: 0.9;
        max-width: 700px;
        margin: 0 auto;
    }

    .company-logo {
        width: 140px;
        height: 140px;
        object-fit: contain;
        background: white;
        padding: 12px;
        border-radius: 50%;
        border: 6px solid white;
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
        position: absolute;
        bottom: -70px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 10;
        animation: float 6s ease-in-out infinite;
    }

    .company-content {
        padding: 6rem 3rem 4rem;
    }

    /* Enhanced Carousel */
    .company-carousel {
        border-radius: var(--border-radius-lg);
        overflow: hidden;
        margin-bottom: 4rem;
        box-shadow: var(--box-shadow);
        position: relative;
    }

    .company-img {
        height: 550px;
        object-fit: cover;
        width: 100%;
        transition: transform 0.8s ease;
    }

    .carousel-item:hover .company-img {
        transform: scale(1.03);
    }

    .carousel-indicators {
        bottom: 30px;
    }

    .carousel-indicators button {
        width: 14px;
        height: 14px;
        border-radius: 50%;
        margin: 0 6px;
        border: 2px solid white;
        background: transparent;
        opacity: 1;
        transition: all 0.3s ease;
    }

    .carousel-indicators button.active {
        background: white;
        transform: scale(1.2);
    }

    .carousel-control-prev,
    .carousel-control-next {
        width: 60px;
        height: 60px;
        top: 50%;
        transform: translateY(-50%);
        border-radius: 50%;
        background: rgba(0,0,0,0.3);
        opacity: 0;
        transition: var(--transition);
    }

    .company-carousel:hover .carousel-control-prev,
    .company-carousel:hover .carousel-control-next {
        opacity: 1;
    }

    .carousel-control-prev {
        left: 30px;
    }

    .carousel-control-next {
        right: 30px;
    }

    .carousel-control-prev:hover,
    .carousel-control-next:hover {
        background: rgba(0,0,0,0.6);
    }

    .carousel-control-prev-icon,
    .carousel-control-next-icon {
        background-size: 1.8rem;
    }

    /* Enhanced Details Cards */
    .company-details {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 2.5rem;
        margin-bottom: 5rem;
    }

    .detail-card {
        background: white;
        border-radius: var(--border-radius-lg);
        padding: 2.2rem;
        box-shadow: var(--box-shadow);
        transition: var(--transition);
        border-top: 5px solid var(--secondary-color);
    }

    .detail-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    }

    .detail-title {
        font-size: 1.4rem;
        font-weight: 700;
        color: var(--primary-color);
        margin-bottom: 1.8rem;
        display: flex;
        align-items: center;
        position: relative;
        padding-bottom: 1rem;
    }

    .detail-title::after {
        content: '';
        position: absolute;
        bottom: 0;
        right: 0;
        width: 60px;
        height: 4px;
        background: var(--accent-color);
        transition: width 0.4s ease;
    }

    .detail-card:hover .detail-title::after {
        width: 100px;
    }

    .detail-title i {
        margin-left: 1rem;
        color: var(--accent-color);
        font-size: 1.8rem;
    }

    /* Section Titles */
    .section-title {
        font-size: 2rem;
        font-weight: 700;
        color: var(--primary-color);
        margin: 5rem 0 2.5rem;
        position: relative;
        padding-right: 2rem;
    }

    .section-title::after {
        content: '';
        position: absolute;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
        width: 6px;
        height: 40px;
        background: var(--accent-color);
        border-radius: 3px;
    }

    /* Enhanced Badges */
    .badge {
        background-color: var(--secondary-color);
        color: white;
        padding: 0.7rem 1.4rem;
        border-radius: 50px;
        font-weight: 600;
        margin: 0 0.8rem 0.8rem 0;
        display: inline-flex;
        align-items: center;
        transition: var(--transition);
    }

    .badge i {
        margin-left: 0.7rem;
        font-size: 0.9rem;
    }

    .badge:hover {
        background-color: var(--primary-color);
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
    }

    /* Projects Grid */
    .projects-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
        gap: 2.5rem;
        margin-bottom: 4rem;
    }

    .project-card {
        border-radius: var(--border-radius-lg);
        overflow: hidden;
        box-shadow: var(--box-shadow);
        transition: var(--transition);
        background: white;
    }

    .project-card:hover {
        transform: translateY(-15px) scale(1.02);
        box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
    }

    .project-img {
        height: 280px;
        object-fit: cover;
        width: 100%;
        transition: transform 0.8s ease, filter 0.4s ease;
    }

    .project-card:hover .project-img {
        transform: scale(1.1);
        filter: brightness(1.05);
    }

    .project-body {
        padding: 2rem;
        position: relative;
        z-index: 1;
        background: white;
    }

    .project-title {
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 1rem;
        color: var(--primary-color);
        transition: color 0.3s ease;
    }

    .project-card:hover .project-title {
        color: var(--accent-color);
    }

    .project-description {
        color: var(--text-light);
        margin-bottom: 1.5rem;
    }

    .project-meta {
        display: flex;
        justify-content: space-between;
        color: var(--text-light);
        font-size: 0.95rem;
    }

    .project-meta i {
        color: var(--accent-color);
        margin-left: 0.5rem;
    }

    /* Certifications */
    .certification-list {
        list-style: none;
        padding: 0;
        margin-bottom: 4rem;
    }

    .certification-item {
        background: white;
        border-radius: var(--border-radius-lg);
        padding: 2rem;
        margin-bottom: 1.5rem;
        box-shadow: var(--box-shadow);
        border-right: 5px solid var(--accent-color);
        transition: var(--transition);
        display: flex;
        align-items: center;
    }

    .certification-item:hover {
        transform: translateX(10px);
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.12);
    }

    .certification-icon {
        font-size: 2.5rem;
        color: var(--accent-color);
        margin-left: 2rem;
        flex-shrink: 0;
    }

    .certification-name {
        font-weight: 700;
        margin-bottom: 0.5rem;
        color: var(--primary-color);
        font-size: 1.2rem;
    }

    .certification-details {
        color: var(--text-light);
    }

    /* Team Section */
    .team-list {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 2.2rem;
        margin-bottom: 4rem;
    }

    .team-member {
        background: white;
        border-radius: var(--border-radius-lg);
        padding: 2rem;
        box-shadow: var(--box-shadow);
        transition: var(--transition);
        display: flex;
        align-items: center;
    }

    .team-member:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
    }

    .team-avatar {
        width: 90px;
        height: 90px;
        border-radius: 50%;
        object-fit: cover;
        margin-left: 1.8rem;
        border: 4px solid var(--light-color);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        transition: var(--transition);
    }

    .team-member:hover .team-avatar {
        transform: scale(1.1);
        border-color: var(--accent-color);
    }

    .team-info h5 {
        font-weight: 700;
        margin-bottom: 0.5rem;
        color: var(--primary-color);
        font-size: 1.2rem;
    }

    .team-info p {
        color: var(--text-light);
        font-size: 1rem;
    }

    .team-social {
        margin-top: 0.8rem;
    }

    .team-social a {
        color: var(--text-light);
        margin-left: 1rem;
        font-size: 1.1rem;
        transition: var(--transition);
    }

    .team-social a:hover {
        color: var(--accent-color);
        transform: translateY(-3px);
    }

    /* Stats Section */
    .stats-container {
        background: linear-gradient(135deg, var(--primary-color), var(--dark-color));
        border-radius: var(--border-radius-lg);
        padding: 4rem 2rem;
        margin: 5rem 0;
        color: white;
        text-align: center;
        box-shadow: var(--box-shadow);
    }

    .stats-title {
        font-size: 1.8rem;
        margin-bottom: 3rem;
        font-weight: 600;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 2rem;
    }

    .stat-item {
        padding: 1.5rem;
    }

    .stat-number {
        font-size: 3.5rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
        color: var(--accent-color);
    }

    .stat-label {
        font-size: 1.1rem;
        opacity: 0.9;
    }

    /* Buttons */
    .btn-primary {
        background-color: var(--accent-color);
        border: none;
        padding: 1rem 2.5rem;
        border-radius: 50px;
        font-weight: 600;
        transition: var(--transition);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
    }

    .btn-primary:hover {
        background-color: #c0392b;
        transform: translateY(-5px) scale(1.05);
        box-shadow: 0 15px 30px rgba(231, 76, 60, 0.4);
    }

    .btn-outline-primary {
        border: 2px solid var(--accent-color);
        color: var(--accent-color);
        border-radius: 50px;
        padding: 1rem 2.5rem;
        font-weight: 600;
        transition: var(--transition);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
    }

    .btn-outline-primary:hover {
        background-color: var(--accent-color);
        color: white;
        transform: translateY(-5px) scale(1.05);
        box-shadow: 0 10px 25px rgba(231, 76, 60, 0.3);
    }

    .btn i {
        margin-left: 0.8rem;
        font-size: 1.2rem;
    }

    /* Action Buttons */
    .action-buttons {
        display: flex;
        justify-content: space-between;
        margin-top: 5rem;
        flex-wrap: wrap;
        gap: 1.5rem;
    }

    .action-buttons .btn {
        flex: 1;
        min-width: 250px;
    }

    /* Empty States */
    .empty-state {
        text-align: center;
        padding: 4rem;
        background: white;
        border-radius: var(--border-radius-lg);
        box-shadow: var(--box-shadow);
        margin-bottom: 4rem;
    }

    .empty-state i {
        font-size: 4rem;
        color: var(--text-light);
        margin-bottom: 2rem;
        opacity: 0.5;
    }

    .empty-state h4 {
        color: var(--primary-color);
        margin-bottom: 1rem;
        font-size: 1.5rem;
    }

    .empty-state p {
        color: var(--text-light);
        font-size: 1.1rem;
        max-width: 500px;
        margin: 0 auto;
    }

    /* Responsive Styles */
    @media (max-width: 1200px) {
        .company-img {
            height: 450px;
        }
        
        .projects-grid {
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        }
    }

    @media (max-width: 992px) {
        .company-header {
            padding: 3rem 1.5rem;
        }
        
        .company-title {
            font-size: 2.4rem;
        }
        
        .company-logo {
            width: 120px;
            height: 120px;
            bottom: -60px;
        }
        
        .company-content {
            padding: 5rem 2rem 3rem;
        }
        
        .company-img {
            height: 400px;
        }
        
        .section-title {
            font-size: 1.8rem;
        }
        
        .stat-number {
            font-size: 3rem;
        }
    }

    @media (max-width: 768px) {
        .company-header {
            padding: 2.5rem 1rem;
        }
        
        .company-title {
            font-size: 2rem;
        }
        
        .company-subtitle {
            font-size: 1.1rem;
        }
        
        .company-logo {
            width: 100px;
            height: 100px;
            bottom: -50px;
        }
        
        .company-content {
            padding: 4rem 1.5rem 2.5rem;
        }
        
        .company-img {
            height: 350px;
        }
        
        .section-title {
            font-size: 1.6rem;
            margin: 4rem 0 2rem;
        }
        
        .company-details {
            grid-template-columns: 1fr;
        }
        
        .projects-grid {
            grid-template-columns: 1fr;
        }
        
        .team-member {
            flex-direction: column;
            text-align: center;
        }
        
        .team-avatar {
            margin-left: 0;
            margin-bottom: 1.5rem;
        }
        
        .stat-number {
            font-size: 2.5rem;
        }
        
        .action-buttons .btn {
            width: 100%;
        }
    }

    @media (max-width: 576px) {
        .company-title {
            font-size: 1.8rem;
        }
        
        .company-img {
            height: 280px;
        }
        
        .section-title {
            font-size: 1.5rem;
            padding-right: 1.5rem;
        }
        
        .section-title::after {
            height: 35px;
        }
        
        .detail-title {
            font-size: 1.3rem;
        }
        
        .empty-state {
            padding: 3rem 1.5rem;
        }
    }
</style>

<div class="company-container">
    <!-- رأس الصفحة -->
    <div class="company-header">
        <h1 class="company-title">{{ $company->name }}</h1>
        <p class="company-subtitle">شركة هندسية متخصصة في تقديم حلول متكاملة</p>
    </div>

    <!-- محتوى الصفحة -->
    <div class="company-content">
        <!-- كارسول الصور -->
        <div id="companyCarousel" class="company-carousel carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                @forelse ($company->images ?? [] as $index => $image)
                    <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                        <img
                            src="{{ asset('storage/' . $image['path']) }}"
                            class="d-block w-100 company-img"
                            alt="{{ $image['caption'] ?? $company->name }}"
                            onerror="this.src='{{ asset('storage/default.jpg') }}'"
                        >
                    </div>
                @empty
                    <div class="carousel-item active">
                                                                      <img src="{{ asset('storage/' . $company->image) }}" class="d-block w-100" alt="{{ $company->name }}" style="height: 200px; object-fit: cover;">

                    </div>
                @endforelse
            </div>
            @if (count($company->images ?? []) > 1)
                <button class="carousel-control-prev" type="button" data-bs-target="#companyCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">السابق</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#companyCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">التالي</span>
                </button>
            @endif
        </div>

        <!-- تفاصيل الشركة -->
        <div class="company-details">
            <div class="detail-card">
                <h3 class="detail-title"><i class="fas fa-info-circle"></i> عن الشركة</h3>
                <p>{{ $company->description ?? 'غير متوفر' }}</p>
            </div>

            <div class="detail-card">
                <h3 class="detail-title"><i class="fas fa-map-marker-alt"></i> الموقع</h3>
                <p>{{ $company->city ?? 'غير محدد' }}</p>
                <p><strong>سنوات الخبرة:</strong> {{ $company->years_experience ?? 'غير محدد' }} سنة</p>
            </div>

            <div class="detail-card">
                <h3 class="detail-title"><i class="fas fa-address-card"></i> معلومات التواصل</h3>
                <p><i class="fas fa-phone me-2"></i> {{ $company->phone ?? 'غير متوفر' }}</p>
                <p><i class="fas fa-envelope me-2"></i> {{ $company->email ?? 'غير متوفر' }}</p>
                <p><i class="fas fa-globe me-2"></i>
                    @if ($company->website)
                        <a href="{{ $company->website }}" target="_blank">{{ $company->website }}</a>
                    @else
                        غير متوفر
                    @endif
                </p>
            </div>
        </div>

        <!-- الخدمات -->
        <h3 class="section-title">الخدمات المقدمة</h3>
        <div>
            @forelse ($company->services ?? [] as $service)
                <span class="badge">{{ $service }}</span>
            @empty
                <p>لا توجد خدمات</p>
            @endforelse
        </div>

        <!-- المشاريع -->
        <h3 class="section-title">المشاريع السابقة</h3>
        <div class="projects-grid">
            @forelse ($company->projects ?? [] as $project)
                <div class="project-card">
                    @if ($project['image'])
                    <img src="{{ asset('storage/' . $company->image) }}" class="d-block w-100" alt="{{ $company->name }}" style="height: 200px; object-fit: cover;">

                    @else
                        <img src="{{ asset('storage/default-project.jpg') }}" class="project-img" alt="مشروع افتراضي">
                    @endif
                    <div class="project-body">
                        <h4 class="project-title">{{ $project['name'] }}</h4>
                        <p>{{ $project['description'] ?? 'غير متوفر' }}</p>
                    </div>
                </div>
            @empty
                <p>لا توجد مشاريع</p>
            @endforelse
        </div>

        <!-- الشهادات -->
        <h3 class="section-title">شهادات الاعتماد</h3>
        <ul class="certification-list">
            @forelse ($company->certifications ?? [] as $cert)
                <li class="certification-item">
                    <h5 class="certification-name">{{ $cert['name'] }}</h5>
                    <p>{{ $cert['issuer'] }} - {{ $cert['year'] }}</p>
                </li>
            @empty
                <p>لا توجد شهادات</p>
            @endforelse
        </ul>

        <!-- فريق العمل -->
        <h3 class="section-title">فريق العمل</h3>
        <div class="team-list">
            @forelse ($company->team ?? [] as $member)
                <div class="team-member">
                    <img src="{{ asset('storage/' . ($member['image'] ?? 'default-avatar.jpg')) }}" class="team-avatar" alt="{{ $member['name'] }}">
                    <div class="team-info">
                        <h5>{{ $member['name'] }}</h5>
                        <p>{{ $member['position'] }}</p>
                    </div>
                </div>
            @empty
                <p>لا يوجد فريق</p>
            @endforelse
        </div>

        <!-- أزرار التنقل -->
        <div class="d-flex justify-content-between mt-5">
            <a href="{{ route('engineering_companies.index') }}" class="btn btn-outline-primary">
                <i class="fas fa-arrow-right me-2"></i> العودة إلى القائمة
            </a>
            <a href="{{ url('contact') }}" class="btn btn-primary">
                <i class="fas fa-envelope me-2"></i> تواصل معنا
            </a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
@endsection