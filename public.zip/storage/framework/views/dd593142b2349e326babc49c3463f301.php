<?php $__env->startSection('title', 'إضافة شركة هندسية'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>إضافة شركة هندسية</h1>
    <form action="<?php echo e(route('engineering_companies.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">اسم الشركة</label>
            <input type="text" name="name" id="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">الوصف</label>
            <textarea name="description" id="description" class="form-control" rows="5"></textarea>
        </div>
        <div class="mb-3">
            <label for="city" class="form-label">المدينة</label>
            <input type="text" name="city" id="city" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="phone" class="form-label">رقم الهاتف</label>
            <input type="text" name="phone" id="phone" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">الإيميل</label>
            <input type="email" name="email" id="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="website" class="form-label">الموقع الإلكتروني</label>
            <input type="url" name="website" id="website" class="form-control">
        </div>
        <div class="mb-3">
            <label for="years_experience" class="form-label">سنوات الخبرة</label>
            <input type="number" name="years_experience" id="years_experience" class="form-control">
        </div>
        <div class="mb-3">
            <label for="image" class="form-label">صورة الشركة</label>
            <input type="file" name="image" id="image" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">إضافة</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\real-estate5\real-estate1\resources\views/engineering_companies/create.blade.php ENDPATH**/ ?>