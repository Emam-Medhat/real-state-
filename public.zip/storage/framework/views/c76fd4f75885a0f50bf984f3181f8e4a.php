

<?php $__env->startSection('title', 'بحث عن عقارات'); ?>

<?php $__env->startSection('content'); ?>
<section class="search-results">
    <div class="container">
        <h2>نتائج البحث</h2>
        <?php if(count($properties) > 0): ?>
            <div class="properties-grid">
                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="property-card">
                        <img src="<?php echo e(asset('img/'.$property->image)); ?>" alt="<?php echo e($property->title); ?>">
                        <div class="property-info">
                            <h3><?php echo e($property->title); ?></h3>
                            <p><?php echo e($property->rooms); ?> غرف • <?php echo e($property->bathrooms); ?> حمام • <?php echo e($property->area); ?> م²</p>
                            <p class="price">السعر: <?php echo e($property->price); ?> جنيه</p>
                            <a href="<?php echo e(route('property.show', $property->id)); ?>" class="details-btn">عرض التفاصيل</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <p>لا توجد نتائج مطابقة لبحثك.</p>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\real-estate5\real-estate1\resources\views/property/search.blade.php ENDPATH**/ ?>