<?php $__env->startSection('title', 'تواصل معنا'); ?>

<?php $__env->startSection('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2C3E50;
            --secondary-color: #3498DB;
            --accent-color: #E74C3C;
            --light-color: #F8F9FA;
            --dark-color: #1A252F;
            --text-color: #333333;
            --text-light: #7F8C8D;
            --success-color: #22C55E;
        }

        body {
            font-family: 'Cairo', sans-serif;
            background: linear-gradient(135deg, #f5f7fa, #e0e7ff);
            color: var(--text-color);
            position: relative;
        }

        .company-container {
            max-width: 1400px;
            margin: 3rem auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeIn 1s ease-in;
        }

        .company-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 3rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .company-header::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle, rgba(255,255,255,0.2), transparent);
            opacity: 0.5;
        }

        .company-title {
            font-size: 3rem;
            font-weight: 900;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 1;
            animation: slideInDown 1s ease;
        }

        .company-subtitle {
            font-size: 1.4rem;
            opacity: 0.9;
            position: relative;
            z-index: 1;
            animation: fadeIn 1.5s ease;
        }

        .company-content {
            padding: 3rem;
        }

        .company-carousel {
            border-radius: 15px;
            overflow: hidden;
            margin-bottom: 3rem;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
        }

        .company-img {
            height: 600px;
            object-fit: cover;
            width: 100%;
            transition: transform 0.5s ease;
        }

        .carousel-item.active .company-img {
            animation: zoomIn 1s ease;
        }

        .carousel-control-prev,
        .carousel-control-next {
            width: 5%;
            background: rgba(0, 0, 0, 0.3);
            transition: opacity 0.3s;
        }

        .carousel-control-prev:hover,
        .carousel-control-next:hover {
            opacity: 1;
            background: rgba(0, 0, 0, 0.5);
        }

        .carousel-control-prev-icon,
        .carousel-control-next-icon {
            background-color: var(--accent-color);
            border-radius: 50%;
            padding: 1.5rem;
            background-size: 1.2rem;
        }

        .company-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .detail-card {
            background: var(--light-color);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            animation: fadeInUp 1s ease;
        }

        .detail-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .detail-title {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
        }

        .detail-title i {
            margin-left: 0.5rem;
            color: var(--accent-color);
            animation: pulse 2s infinite;
        }

        .section-title {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-color);
            margin: 3rem 0 1.5rem;
            position: relative;
            padding-right: 2rem;
            animation: slideInLeft 1s ease;
        }

        .section-title::after {
            content: '';
            position: absolute;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 6px;
            height: 40px;
            background: var(--accent-color);
            border-radius: 3px;
        }

        .badge {
            background-color: var(--secondary-color);
            padding: 0.6rem 1.2rem;
            border-radius: 50px;
            font-weight: 600;
            margin: 0.3rem;
            display: inline-block;
            transition: transform 0.3s;
        }

        .badge:hover {
            transform: scale(1.1);
        }

        .projects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .project-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            animation: fadeInUp 1.2s ease;
        }

        .project-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .project-img {
            height: 250px;
            object-fit: cover;
            width: 100%;
            transition: transform 0.5s ease;
        }

        .project-card:hover .project-img {
            transform: scale(1.05);
        }

        .project-body {
            padding: 1.5rem;
        }

        .project-title {
            font-size: 1.4rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--primary-color);
        }

        .certification-list {
            list-style: none;
            padding: 0;
            margin-bottom: 3rem;
        }

        .certification-item {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
            border-right: 4px solid var(--accent-color);
            animation: fadeInRight 1.3s ease;
        }

        .team-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 3rem;
        }

        .team-member {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            transition: transform 0.3s;
            animation: fadeInUp 1.4s ease;
        }

        .team-member:hover {
            transform: translateY(-5px);
        }

        .team-avatar {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            margin-left: 1rem;
            border: 3px solid var(--light-color);
            transition: transform 0.3s;
        }

        .team-member:hover .team-avatar {
            transform: rotate(360deg);
        }

        .btn-primary {
            background-color: var(--accent-color);
            border: none;
            padding: 0.8rem 2rem;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s;
            animation: pulse 2s infinite;
        }

        .btn-primary:hover {
            background-color: #c0392b;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
            animation: none;
        }

        .btn-outline-primary {
            border-color: var(--accent-color);
            color: var(--accent-color);
            border-radius: 50px;
            transition: all 0.3s;
        }

        .btn-outline-primary:hover {
            background-color: var(--accent-color);
            color: white;
            transform: translateY(-3px);
        }

        .stats-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            margin: 3rem 0;
            padding: 2rem;
            background: var(--light-color);
            border-radius: 15px;
            animation: fadeIn 1.5s ease;
        }

        .stat-card {
            text-align: center;
            padding: 1.5rem;
            border-radius: 10px;
            background: white;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--success-color);
        }

        .news-ticker {
            background: var(--primary-color);
            color: white;
            padding: 1rem;
            margin-bottom: 3rem;
            border-radius: 10px;
            overflow: hidden;
            position: relative;
        }

        .news-ticker ul {
            list-style: none;
            padding: 0;
            margin: 0;
            animation: ticker 20s linear infinite;
        }

        .news-ticker li {
            padding: 0.5rem 0;
            font-size: 1.1rem;
        }

        .map-container {
            height: 400px;
            border-radius: 15px;
            overflow: hidden;
            margin-bottom: 3rem;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            animation: fadeIn 1.6s ease;
        }

        .loading-spinner {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.5s;
        }

        .spinner {
            border: 8px solid var(--light-color);
            border-top: 8px solid var(--accent-color);
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInRight {
            from { opacity: 0; transform: translateX(20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes slideInDown {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes slideInLeft {
            from { transform: translateX(-50px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes zoomIn {
            from { transform: scale(1); }
            to { transform: scale(1.05); }
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes ticker {
            0% { transform: translateY(0); }
            100% { transform: translateY(-100%); }
        }

        @media (max-width: 768px) {
            .company-title { font-size: 2.2rem; }
            .company-img { height: 400px; }
            .projects-grid { grid-template-columns: 1fr; }
            .team-list { grid-template-columns: 1fr; }
            .stats-section { grid-template-columns: 1fr; }
        }

        @media (max-width: 576px) {
            .company-header { padding: 2rem; }
            .company-title { font-size: 1.8rem; }
            .company-img { height: 300px; }
            .section-title { font-size: 1.6rem; }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Loading Spinner -->
    <div class="loading-spinner" id="loadingSpinner">
        <div class="spinner"></div>
    </div>

    <!-- Company Container -->
    <div class="company-container">
        <!-- Header -->
        <div class="company-header">
            <h1 class="company-title"><?php echo e($company->name); ?></h1>
            <p class="company-subtitle">شركة هندسية رائدة تقدم حلولًا مبتكرة ومتكاملة في جميع أنحاء الوطن العربي</p>
        </div>

        <!-- Content -->
        <div class="company-content">
            <!-- News Ticker -->
            <div class="news-ticker">
                <ul>
                    <li>افتتاح فرع جديد في دبي 2025</li>
                    <li>فوز الشركة بجائزة أفضل تصميم هندسي 2024</li>
                    <li>إتمام مشروع المدينة الذكية بنجاح</li>
                    <li>توسع الشركة في السوق السعودي</li>
                </ul>
            </div>

            <!-- Image Carousel -->
            <div id="companyCarousel" class="company-carousel carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php $__empty_1 = true; $__currentLoopData = $company->images ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                            <img
                                src="<?php echo e(asset('storage/' . $image['path'])); ?>"
                                class="d-block w-100 company-img"
                                alt="<?php echo e($image['caption'] ?? $company->name); ?>"
                                onerror="this.src='<?php echo e(asset('storage/default.jpg')); ?>'"
                            >
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="carousel-item active">
                            <img
                                src="<?php echo e(asset('storage/default.jpg')); ?>"
                                class="d-block w-100 company-img"
                                alt="صورة افتراضية"
                            >
                        </div>
                        <div class="carousel-item">
                            <img
                                src="<?php echo e(asset('storage/company2.jpg')); ?>"
                                class="d-block w-100 company-img"
                                alt="صورة إضافية"
                            >
                        </div>
                    <?php endif; ?>
                </div>
                <?php if(count($company->images ?? []) > 1 || true): ?>
                    <button class="carousel-control-prev" type="button" data-bs-target="#companyCarousel" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">السابق</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#companyCarousel" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">التالي</span>
                    </button>
                <?php endif; ?>
            </div>

            <!-- Company Details -->
            <div class="company-details">
                <div class="detail-card">
                    <h3 class="detail-title"><i class="fas fa-info-circle"></i> عن الشركة</h3>
                    <p><?php echo e($company->description ?? 'شركة رائدة في مجال الهندسة المدنية والمعمارية، تأسست عام 2000، وتقدم حلولًا مبتكرة للمشاريع الكبرى.'); ?></p>
                </div>
                <div class="detail-card">
                    <h3 class="detail-title"><i class="fas fa-map-marker-alt"></i> الموقع</h3>
                    <p><?php echo e($company->city ?? 'القاهرة، مصر'); ?></p>
                    <p><strong>سنوات الخبرة:</strong> <?php echo e($company->years_experience ?? 25); ?> سنة</p>
                    <p><strong>الفروع:</strong> الرياض، دبي، بيروت</p>
                </div>
                <div class="detail-card">
                    <h3 class="detail-title"><i class="fas fa-address-card"></i> معلومات التواصل</h3>
                    <p><i class="fas fa-phone me-2"></i> <?php echo e($company->phone ?? '+20 123 456 7890'); ?></p>
                    <p><i class="fas fa-envelope me-2"></i> <?php echo e($company->email ?? 'info@example.com'); ?></p>
                    <p><i class="fas fa-globe me-2"></i>
                        <?php if($company->website): ?>
                            <a href="<?php echo e($company->website); ?>" target="_blank" rel="noopener noreferrer"><?php echo e($company->website); ?></a>
                        <?php else: ?>
                            <a href="https://example.com" target="_blank" rel="noopener noreferrer">www.example.com</a>
                        <?php endif; ?>
                    </p>
                </div>
            </div>

            <!-- Statistics -->
            <div class="stats-section">
                <div class="stat-card">
                    <div class="stat-number">500+</div>
                    <p>مشروع مكتمل</p>
                </div>
                <div class="stat-card">
                    <div class="stat-number">25</div>
                    <p>سنة خبرة</p>
                </div>
                <div class="stat-card">
                    <div class="stat-number">1000+</div>
                    <p>عميل راضٍ</p>
                </div>
                <div class="stat-card">
                    <div class="stat-number">15</div>
                    <p>جائزة عالمية</p>
                </div>
            </div>

            <!-- Services -->
            <h3 class="section-title">الخدمات المقدمة</h3>
            <div class="mb-4">
                <?php $__empty_1 = true; $__currentLoopData = $company->services ?? ['تصميم معماري', 'هندسة مدنية', 'إدارة مشاريع', 'تشطيب داخلي', 'استشارات هندسية']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <span class="badge animate__animated animate__bounceIn"><?php echo e($service); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">لا توجد خدمات متاحة</p>
                <?php endif; ?>
            </div>

            <!-- Projects -->
            <h3 class="section-title">المشاريع السابقة</h3>
            <div class="projects-grid">
                <?php $__empty_1 = true; $__currentLoopData = $company->projects ?? [
                    ['name' => 'المدينة الذكية', 'image' => 'projects/smart-city.jpg', 'description' => 'مشروع مدينة متكاملة بتقنيات حديثة.'],
                    ['name' => 'برج المستقبل', 'image' => 'projects/future-tower.jpg', 'description' => 'برج سكني بتصميم عصري.'],
                    ['name' => 'جسر الأمل', 'image' => 'projects/hope-bridge.jpg', 'description' => 'جسر يربط ضفتي النهر.'],
                    ['name' => 'مجمع تجاري', 'image' => 'projects/mall.jpg', 'description' => 'مركز تجاري متعدد الطوابق.']
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="project-card animate__animated animate__fadeInUp">
                        <img
                            src="<?php echo e(asset('storage/' . ($project['image'] ?? 'default-project.jpg'))); ?>"
                            class="project-img"
                            alt="<?php echo e($project['name']); ?>"
                            onerror="this.src='<?php echo e(asset('storage/default-project.jpg')); ?>'"
                        >
                        <div class="project-body">
                            <h4 class="project-title"><?php echo e($project['name']); ?></h4>
                            <p><?php echo e($project['description'] ?? 'غير متوفر'); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">لا توجد مشاريع مسجلة</p>
                <?php endif; ?>
            </div>

            <!-- Certifications -->
            <h3 class="section-title">شهادات الاعتماد</h3>
            <ul class="certification-list">
                <?php $__empty_1 = true; $__currentLoopData = $company->certifications ?? [
                    ['name' => 'ISO 9001', 'issuer' => 'المنظمة الدولية للتوحيد القياسي', 'year' => 2020],
                    ['name' => 'LEED Certification', 'issuer' => 'مجلس المباني الخضراء', 'year' => 2021],
                    ['name' => 'PMP Certification', 'issuer' => 'معهد إدارة المشاريع', 'year' => 2019]
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="certification-item animate__animated animate__fadeInRight">
                        <h5 class="certification-name"><?php echo e($cert['name']); ?></h5>
                        <p><?php echo e($cert['issuer']); ?> - <?php echo e($cert['year']); ?></p>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">لا توجد شهادات اعتماد</p>
                <?php endif; ?>
            </ul>

            <!-- Team -->
            <h3 class="section-title">فريق العمل</h3>
            <div class="team-list">
                <?php $__empty_1 = true; $__currentLoopData = $company->team ?? [
                    ['name' => 'أحمد محمد', 'position' => 'مهندس أول', 'image' => 'team/ahmed.jpg'],
                    ['name' => 'سارة علي', 'position' => 'مديرة مشاريع', 'image' => 'team/sara.jpg'],
                    ['name' => 'محمود حسن', 'position' => 'مصمم معماري', 'image' => 'team/mahmoud.jpg'],
                    ['name' => 'ليلى خالد', 'position' => 'استشاري هندسي', 'image' => 'team/laila.jpg']
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="team-member animate__animated animate__fadeInUp">
                        <img
                            src="<?php echo e(asset('storage/' . ($member['image'] ?? 'default-avatar.jpg'))); ?>"
                            class="team-avatar"
                            alt="<?php echo e($member['name']); ?>"
                            onerror="this.src='<?php echo e(asset('storage/default-avatar.jpg')); ?>'"
                        >
                        <div class="team-info">
                            <h5><?php echo e($member['name']); ?></h5>
                            <p><?php echo e($member['position']); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">لا يوجد أعضاء فريق مسجلين</p>
                <?php endif; ?>
            </div>

            <!-- Interactive Map -->
            <h3 class="section-title">مواقع الفروع</h3>
            <div class="map-container">
                <img
                    src="https://via.placeholder.com/1200x400?text=خريطة+تفاعلية+للفروع"
                    class="img-fluid w-100 h-100"
                    alt="خريطة الفروع"
                >
            </div>

            <!-- Navigation Buttons -->
            <div class="d-flex justify-content-between mt-5">
                <a href="<?php echo e(route('engineering_companies.index')); ?>" class="btn btn-outline-primary animate__animated animate__bounceIn">
                    <i class="fas fa-arrow-right me-2"></i> العودة إلى القائمة
                </a>
                <a href="<?php echo e(url('contact')); ?>" class="btn btn-primary">
                    <i class="fas fa-envelope me-2"></i> تواصل معنا
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Hide loading spinner after page load
        window.addEventListener('load', () => {
            const spinner = document.getElementById('loadingSpinner');
            spinner.style.opacity = '0';
            setTimeout(() => spinner.remove(), 500);
        });

        // Scroll reveal animation
        const revealElements = document.querySelectorAll('.animate__animated');
        const revealOnScroll = () => {
            revealElements.forEach(el => {
                const rect = el.getBoundingClientRect();
                if (rect.top < window.innerHeight * 0.8) {
                    el.classList.add('animate__fadeInUp');
                }
            });
        };
        window.addEventListener('scroll', revealOnScroll);
        revealOnScroll();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\real-estate5\real-estate1\resources\views/engineering_companies/show.blade.php ENDPATH**/ ?>