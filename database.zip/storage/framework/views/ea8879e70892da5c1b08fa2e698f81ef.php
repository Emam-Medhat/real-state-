<?php $__env->startSection('title', 'طلبات الصيانة'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .maintenance-requests-container {
        max-width: 900px;
        margin: 40px auto;
        padding: 20px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .section-title {
        font-size: 1.8rem;
        font-weight: bold;
        color: #333;
        margin-bottom: 20px;
        text-align: center;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    .table th, .table td {
        padding: 10px;
        border: 1px solid #ddd;
        text-align: center;
    }

    .table th {
        background-color: #f4f4f4;
        font-weight: bold;
    }

    .btn-view {
        background-color: #007bff;
        color: #fff;
        text-decoration: none;
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 0.9rem;
    }

    .btn-view:hover {
        background-color: #0056b3;
    }

    .status-pending {
        color: orange;
        font-weight: bold;
    }

    .status-in-progress {
        color: blue;
        font-weight: bold;
    }

    .status-completed {
        color: green;
        font-weight: bold;
    }

    .status-cancelled {
        color: red;
        font-weight: bold;
    }

    .image-preview {
        max-width: 100px;
        margin: 5px auto;
    }
</style>

<div class="maintenance-requests-container">
    <h1 class="section-title">طلبات الصيانة</h1>

    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>العقار</th>
                <th>نوع المشكلة</th>
                <th>الأهمية</th>
                <th>الحالة</th>
                <th>تاريخ الإنشاء</th>
                <th>صورة</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maintenanceRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($maintenanceRequest->property->title ?? 'غير متوفر'); ?></td>
                <td>
                    <?php switch($maintenanceRequest->issue_type):
                        case ('plumbing'): ?> مشاكل سباكة <?php break; ?>
                        <?php case ('electrical'): ?> مشاكل كهرباء <?php break; ?>
                        <?php case ('structural'): ?> مشاكل هيكلية <?php break; ?>
                        <?php default: ?> أخرى
                    <?php endswitch; ?>
                </td>
                <td>
                    <?php if($maintenanceRequest->priority === 'urgent'): ?>
                        <span style="color: red; font-weight: bold;">عاجل</span>
                    <?php else: ?>
                        عادي
                    <?php endif; ?>
                </td>
                <td>
                    <?php switch($maintenanceRequest->status):
                        case ('pending'): ?> <span class="status-pending">قيد المراجعة</span> <?php break; ?>
                        <?php case ('in_progress'): ?> <span class="status-in-progress">جاري التنفيذ</span> <?php break; ?>
                        <?php case ('completed'): ?> <span class="status-completed">مكتمل</span> <?php break; ?>
                        <?php case ('cancelled'): ?> <span class="status-cancelled">ملغي</span> <?php break; ?>
                    <?php endswitch; ?>
                </td>
                <td><?php echo e($maintenanceRequest->created_at->format('Y-m-d')); ?></td>
                <td>
                    <?php if($maintenanceRequest->images): ?>
                        <img src="<?php echo e(asset('storage/' . $maintenanceRequest->images)); ?>" alt="صورة المشكلة" style="max-width: 300px;">
                    <?php else: ?>
                        <p>لا توجد صورة</p>
                    <?php endif; ?>
                </td>
                <td>
                    
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\real-estate5\real-estate1\resources\views/maintenance_request/index.blade.php ENDPATH**/ ?>