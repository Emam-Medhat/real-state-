
@extends('layouts.app')

@section('title', 'الملف الشخصي')

@section('content')
<section class="profile-section">
    <div class="container">
        <h2>الملف الشخصي</h2>

        <!-- عرض الصورة الشخصية -->
        <div class="profile-image">
            @if($user->image)
            <img src="{{ asset('storage/PropertyPhotos/' . $user->image) }}" alt="Profile Image" style="max-width: 150px; max-height: 150px; border-radius: 50%;">
        @else
            <p>لا توجد صورة حالياً</p>
        @endif
        
        
        
        </div>

        <!-- عرض الاسم الكامل -->
        <div class="profile-details">
            <p><strong>الاسم الكامل:</strong> {{ $user->name }}</p>
            <p><strong>البريد الإلكتروني:</strong> {{ $user->email }}</p>
        </div>

        <!-- رابط لتعديل الملف الشخصي -->
        <div class="profile-actions">
            <a href="{{ route('profile.edit') }}" class="btn btn-primary">تعديل الملف الشخصي</a>
        </div>
        <div class="logout-section" style="margin-top: 20px;">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="btn btn-danger">تسجيل الخروج</button>
        
    </div>
</section>
@endsection
