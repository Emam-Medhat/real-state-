{{-- @extends('layouts.app')

@section('title', 'تعديل الملف الشخصي')

@section('content') --}}



<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>طلب صيانة عقار</title>
    <!-- Bootstrap 5 RTL -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts - Tajawal -->
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;900&display=swap" rel="stylesheet">
    <!-- Select2 RTL -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.rtl.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --danger-color: #f72585;
            --warning-color: #f8961e;
            --success-color: #4cc9f0;
            --dark-color: #1a1a2e;
            --light-color: #f8f9fa;
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: var(--dark-color);
        }

        .maintenance-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 50px rgba(67, 97, 238, 0.15);
            overflow: hidden;
            width: 100%;
            max-width: 1200px;
            margin: 30px auto;
            transition: all 0.3s ease;
        }

        .maintenance-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .maintenance-header::before {
            content: "";
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
            transform: rotate(30deg);
        }

        .maintenance-title {
            font-weight: 900;
            font-size: 2.5rem;
            margin-bottom: 10px;
            position: relative;
            text-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .maintenance-subtitle {
            font-weight: 500;
            opacity: 0.9;
            font-size: 1.1rem;
        }

        .maintenance-body {
            padding: 40px;
        }

        .section-title {
            color: var(--primary-color);
            font-weight: 700;
            font-size: 1.5rem;
            margin-bottom: 25px;
            position: relative;
            padding-right: 15px;
        }

        .section-title::after {
            content: "";
            position: absolute;
            right: 0;
            bottom: -8px;
            width: 50px;
            height: 3px;
            background: var(--accent-color);
            border-radius: 3px;
        }

        .form-label {
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 8px;
        }

        .form-control, .form-select, .select2-selection {
            border: 2px solid #e0e3ed;
            border-radius: 12px;
            padding: 12px 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: #f8f9fc;
        }

        .form-control:focus, .form-select:focus, .select2-selection--single:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(72, 149, 239, 0.2);
            background-color: white;
        }

        textarea.form-control {
            min-height: 150px;
        }

        .btn-main {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border: none;
            border-radius: 12px;
            padding: 12px 30px;
            font-weight: 700;
            color: white;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }

        .btn-main:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(67, 97, 238, 0.4);
            color: white;
        }

        .btn-main:active {
            transform: translateY(1px);
        }

        .btn-add {
            background: var(--accent-color);
            color: white;
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-add:hover {
            background: var(--secondary-color);
            color: white;
        }

        .issue-card {
            background: white;
            border: 2px solid #e0e3ed;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            position: relative;
            overflow: hidden;
        }

        .issue-card:hover {
            border-color: var(--accent-color);
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(67, 97, 238, 0.1);
        }

        .issue-card input:checked + .issue-content {
            border-color: var(--primary-color);
            background-color: rgba(67, 97, 238, 0.05);
        }

        .issue-icon {
            font-size: 1.8rem;
            color: var(--primary-color);
            margin-left: 15px;
            flex-shrink: 0;
        }

        .issue-content {
            flex-grow: 1;
        }

        .issue-title {
            font-weight: 700;
            margin-bottom: 5px;
            color: var(--dark-color);
        }

        .image-upload-container {
            background: #f8f9fc;
            border: 2px dashed #e0e3ed;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

        .image-upload-container:hover {
            border-color: var(--accent-color);
            background: rgba(72, 149, 239, 0.05);
        }

        .image-preview {
            width: 100%;
            max-width: 150px;
            border-radius: 10px;
            margin: 10px auto;
            display: block;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }

        .image-preview:hover {
            transform: scale(1.05);
        }

        .remove-image {
            color: var(--danger-color);
            cursor: pointer;
            font-size: 1.5rem;
            transition: all 0.3s ease;
            position: absolute;
            top: 10px;
            left: 10px;
            background: white;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .remove-image:hover {
            transform: scale(1.2);
        }

        .priority-high {
            border-left: 4px solid var(--danger-color);
        }

        .priority-normal {
            border-left: 4px solid var(--warning-color);
        }

        .alert-container {
            border-radius: 15px;
            margin-bottom: 30px;
        }

        @media (max-width: 768px) {
            .maintenance-body {
                padding: 25px;
            }

            .maintenance-title {
                font-size: 2rem;
            }

            .section-title {
                font-size: 1.3rem;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.6s ease forwards;
        }

        .delay-1 { animation-delay: 0.1s; }
        .delay-2 { animation-delay: 0.2s; }
        .delay-3 { animation-delay: 0.3s; }
        .delay-4 { animation-delay: 0.4s; }
    </style>
</head>
<body>
    <div class="maintenance-card fade-in">
        <div class="maintenance-header">
            <h1 class="maintenance-title">
                <i class="fas fa-tools me-2"></i> طلب صيانة عقار
            </h1>
            <p class="maintenance-subtitle">املأ النموذج أدناه لطلب خدمة الصيانة لعقارك</p>
        </div>

        <div class="maintenance-body">
            @if ($errors->any())
                <div class="alert alert-danger alert-container fade-in">
                    <h5 class="alert-heading">يوجد خطأ في البيانات المقدمة</h5>
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('maintenance_requests.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <!-- Property Selection Section -->
                <div class="mb-5 fade-in delay-1">
                    <h3 class="section-title">
                        <i class="fas fa-home me-2"></i> معلومات العقار
                    </h3>

                    <div class="row">
                        <div class="col-md-12">
                            <label for="property_id" class="form-label">اختر العقار المطلوب صيانته</label>
                            <select name="property_id" id="property_id" class="form-select" required>
                                <option value="">-- اختر عقارًا --</option>
                                @foreach ($properties as $property)
                                    <option value="{{ $property->id }}" {{ old('property_id') == $property->id ? 'selected' : '' }}>
                                        {{ $property->title }} ({{ $property->city }}{{ $property->neighborhood ? ', ' . $property->neighborhood : '' }})
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Issue Type Section -->
                <div class="mb-5 fade-in delay-2">
                    <h3 class="section-title">
                        <i class="fas fa-exclamation-triangle me-2"></i> نوع المشكلة
                    </h3>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="issue-card">
                                <input type="radio" name="issue_type" value="plumbing" id="plumbing" {{ old('issue_type') == 'plumbing' ? 'checked' : '' }} required class="d-none">
                                <div class="issue-content">
                                    <div class="issue-title">مشاكل سباكة</div>
                                    <p class="mb-0 text-muted">تسرب مياه، انسداد مجاري، أعطال في الحمامات</p>
                                </div>
                                <div class="issue-icon">
                                    <i class="fas fa-faucet"></i>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="issue-card">
                                <input type="radio" name="issue_type" value="electrical" id="electrical" {{ old('issue_type') == 'electrical' ? 'checked' : '' }} required class="d-none">
                                <div class="issue-content">
                                    <div class="issue-title">مشاكل كهربائية</div>
                                    <p class="mb-0 text-muted">أعطال في الكهرباء، مشاكل في الإضاءة، أسلاك تالفة</p>
                                </div>
                                <div class="issue-icon">
                                    <i class="fas fa-bolt"></i>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="issue-card">
                                <input type="radio" name="issue_type" value="structural" id="structural" {{ old('issue_type') == 'structural' ? 'checked' : '' }} required class="d-none">
                                <div class="issue-content">
                                    <div class="issue-title">مشاكل هيكلية</div>
                                    <p class="mb-0 text-muted">تصدعات في الجدران، مشاكل في الأسقف، أعطال في الأساسات</p>
                                </div>
                                <div class="issue-icon">
                                    <i class="fas fa-building"></i>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="issue-card">
                                <input type="radio" name="issue_type" value="other" id="other" {{ old('issue_type') == 'other' ? 'checked' : '' }} required class="d-none">
                                <div class="issue-content">
                                    <div class="issue-title">مشاكل أخرى</div>
                                    <p class="mb-0 text-muted">أي مشاكل أخرى لم يتم ذكرها أعلاه</p>
                                </div>
                                <div class="issue-icon">
                                    <i class="fas fa-question-circle"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Issue Description Section -->
                <div class="mb-5 fade-in delay-3">
                    <h3 class="section-title">
                        <i class="fas fa-file-alt me-2"></i> وصف المشكلة
                    </h3>

                    <div class="row">
                        <div class="col-md-12">
                            <label for="description" class="form-label">وصف مفصل للمشكلة</label>
                            <textarea name="description" id="description" class="form-control" rows="6" placeholder="صف المشكلة بالتفصيل، متى بدأت، وأي معلومات أخرى تساعد في فهم المشكلة..." required>{{ old('description') }}</textarea>
                        </div>
                    </div>
                </div>

                <!-- Priority Section -->
                <div class="mb-5 fade-in delay-3">
                    <h3 class="section-title">
                        <i class="fas fa-exclamation-circle me-2"></i> مستوى الأهمية
                    </h3>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="issue-card priority-high">
                                <input type="radio" name="priority" value="urgent" id="urgent" {{ old('priority') == 'urgent' ? 'checked' : '' }} required class="d-none">
                                <div class="issue-content">
                                    <div class="issue-title">عاجل</div>
                                    <p class="mb-0 text-muted">المشكلة تؤثر على استخدام العقار أو تشكل خطرًا</p>
                                </div>
                                <div class="issue-icon">
                                    <i class="fas fa-fire"></i>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="issue-card priority-normal">
                                <input type="radio" name="priority" value="normal" id="normal" {{ old('priority') == 'normal' ? 'checked' : '' }} required class="d-none">
                                <div class="issue-content">
                                    <div class="issue-title">عادي</div>
                                    <p class="mb-0 text-muted">المشكلة غير عاجلة ولا تؤثر على استخدام العقار</p>
                                </div>
                                <div class="issue-icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Images Section -->
                <div class="mb-5 fade-in delay-4">
                    <h3 class="section-title">
                        <i class="fas fa-camera me-2"></i> صور المشكلة
                    </h3>

                    <div class="row">
                        <div class="col-md-12">
                            <label class="form-label">إرفاق صور للمشكلة (اختياري)</label>

                            <div id="image-upload-fields">
                                <div class="image-upload-container position-relative">
                                    <input type="file" name="images[0][file]" accept="image/*" class="form-control d-none" id="image-0" onchange="previewImage(this)">
                                    <label for="image-0" class="btn btn-add w-100">
                                        <i class="fas fa-plus-circle me-2"></i> إضافة صورة
                                    </label>
                                    <input type="text" name="images[0][caption]" class="form-control mt-3" placeholder="وصف الصورة (اختياري)" value="{{ old('images.0.caption') }}">
                                    <img class="image-preview d-none" alt="معاينة الصورة">
                                    <i class="fas fa-times remove-image d-none" onclick="removeImage(this)"></i>
                                </div>
                            </div>

                            <button type="button" class="btn btn-add mt-3" onclick="addImageField()">
                                <i class="fas fa-plus me-2"></i> إضافة صورة أخرى
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="text-center mt-5 fade-in delay-4">
                    <button type="submit" class="btn btn-main px-5 py-3">
                        <i class="fas fa-paper-plane me-2"></i> إرسال طلب الصيانة
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Select2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        // Initialize Select2
        $(document).ready(function() {
            $('#property_id').select2({
                placeholder: "-- اختر عقارًا --",
                allowClear: true,
                theme: "bootstrap-5",
                width: '100%',
                dropdownParent: $('.maintenance-card')
            });

            // Style radio buttons when card is clicked
            $('.issue-card').click(function() {
                $(this).find('input[type="radio"]').prop('checked', true);
                $('.issue-card').removeClass('selected');
                $(this).addClass('selected');
            });
        });

        let imageFieldCount = 1;

        function addImageField() {
            const container = document.getElementById('image-upload-fields');
            const newField = document.createElement('div');
            newField.className = 'image-upload-container position-relative mt-3';
            newField.innerHTML = `
                <input type="file" name="images[${imageFieldCount}][file]" accept="image/*" class="form-control d-none" id="image-${imageFieldCount}" onchange="previewImage(this)">
                <label for="image-${imageFieldCount}" class="btn btn-add w-100">
                    <i class="fas fa-plus-circle me-2"></i> إضافة صورة
                </label>
                <input type="text" name="images[${imageFieldCount}][caption]" class="form-control mt-3" placeholder="وصف الصورة (اختياري)">
                <img class="image-preview d-none" alt="معاينة الصورة">
                <i class="fas fa-times remove-image d-none" onclick="removeImage(this)"></i>
            `;
            container.appendChild(newField);
            imageFieldCount++;
        }

        function previewImage(input) {
            const container = input.closest('.image-upload-container');
            const preview = container.querySelector('.image-preview');
            const removeBtn = container.querySelector('.remove-image');

            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.classList.remove('d-none');
                    removeBtn.classList.remove('d-none');
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        function removeImage(button) {
            const container = button.closest('.image-upload-container');
            const fileInput = container.querySelector('input[type="file"]');
            const preview = container.querySelector('.image-preview');

            fileInput.value = '';
            preview.src = '';
            preview.classList.add('d-none');
            button.classList.add('d-none');
        }
    </script>
</body>
</html>

{{-- @endsection --}}