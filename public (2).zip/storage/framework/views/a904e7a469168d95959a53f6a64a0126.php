


<?php $__env->startSection('title', 'الملف الشخصي'); ?>

<?php $__env->startSection('content'); ?>
<section class="profile-section">
    <div class="container">
        <h2>الملف الشخصي</h2>

        <!-- عرض الصورة الشخصية -->
        <div class="profile-image">
            <?php if($user->image): ?>
            <img src="<?php echo e(asset('storage/PropertyPhotos/' . $user->image)); ?>" alt="Profile Image" style="max-width: 150px; max-height: 150px; border-radius: 50%;">
        <?php else: ?>
            <p>لا توجد صورة حالياً</p>
        <?php endif; ?>
        
        
        
        </div>

        <!-- عرض الاسم الكامل -->
        <div class="profile-details">
            <p><strong>الاسم الكامل:</strong> <?php echo e($user->name); ?></p>
            <p><strong>البريد الإلكتروني:</strong> <?php echo e($user->email); ?></p>
        </div>

        <!-- رابط لتعديل الملف الشخصي -->
        <div class="profile-actions">
            <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-primary">تعديل الملف الشخصي</a>
        </div>
        <div class="logout-section" style="margin-top: 20px;">
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">تسجيل الخروج</button>
        
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\real-estate5\real-estate1\resources\views/profile/show.blade.php ENDPATH**/ ?>