<div class="gallery">
    <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="image-card shadow-sm">
            <img src="<?php echo e($image['url']); ?>" class="w-100" style="height: 200px; object-fit: cover;">
            <div class="image-info">
                <h6><?php echo e($image['name']); ?></h6>
                <small class="text-muted d-block">الحجم: <?php echo e($image['size']); ?></small>
                <small class="text-muted d-block">آخر تعديل: <?php echo e($image['modified']); ?></small>
                <form action="<?php echo e(route('images.delete', $image['name'])); ?>" method="POST" class="mt-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm">حذف</button>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 text-center py-5">
            <p class="text-muted">لا توجد صور متاحة</p>
        </div>
    <?php endif; ?>
</div><?php /**PATH F:\real-estate5\real-estate1\resources\views/image.blade.php ENDPATH**/ ?>