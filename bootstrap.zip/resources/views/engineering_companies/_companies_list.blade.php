@foreach ($companies as $company)
    <div class="col-xl-4 col-lg-6 col-md-6 mb-4">
        <div class="company-card card h-100">
            <!-- محتوى الكارت -->
        </div>
    </div>
@endforeach